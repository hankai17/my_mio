set print pretty

b poll1
