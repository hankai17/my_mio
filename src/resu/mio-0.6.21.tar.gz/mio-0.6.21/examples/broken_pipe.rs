extern crate mio;

use mio::{Events, Poll, PollOpt, Ready, Registration, SetReadiness, Token};
use mio::deprecated::{unix, EventLoop, Handler};
use std::time::Duration;
use mio::event::Evented;

pub struct BrokenPipeHandler;

impl Handler for BrokenPipeHandler {
    type Timeout = ();
    type Message = ();
    fn ready(&mut self, _: &mut EventLoop<Self>, token: Token, _: Ready) {
        println!("BrokenPipeHandler ready");
        if token == Token(1) {
            panic!("Received ready() on a closed pipe.");
        }
    }
}

pub fn test2() {
    let mut event_loop: EventLoop<BrokenPipeHandler> = EventLoop::new().unwrap();
    let (reader, writer) = unix::pipe().unwrap();

    event_loop.register(&reader, Token(1), Ready::all(), PollOpt::edge())
              .unwrap();

    let mut handler = BrokenPipeHandler;
    drop(reader);
    event_loop.run_once(&mut handler, Some(Duration::from_millis(1000))).unwrap();
    println!("1BrokenPipeHandler ready");
}


fn test1() {
    let poll = Poll::new().unwrap();
    let mut events = Events::with_capacity(128);
    let (r, set) = Registration::new2();

    r.register(&poll, Token(0), Ready::readable(), PollOpt::edge()).unwrap(); // 分配node 初始化之(记录监听的事件 queue指向poll中的queue)
    let n = poll.poll(&mut events, Some(Duration::from_millis(0))).unwrap();
    assert_eq!(n, 0);

    set.set_readiness(Ready::readable()).unwrap();
    let n = poll.poll(&mut events, Some(Duration::from_millis(0))).unwrap();
    assert_eq!(n, 1);

    assert_eq!(events.get(0).unwrap().token(), Token(0));
}

fn main() {
    test1();

}
